package projectoop;
//==============================================================================================================================================================

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
//==============================================================================================================================================================

public class AdminPage extends JFrame implements ActionListener {

//variables
     CardLayout cardLayout;
     JButton DashboardPage, FindStudentPage, AddStudentPage, FindTeacherPage, AddTeacherPage, CoursePage, GradePage, LogoutBtn, StuSearchBtn, FindTeacherBtn, AddStuBtn, GradeBtn1, GradeBtn2, AddTeacherBtn, CourseBtn,DeletionPage, DeleteBtn;
     JPanel sidebar, header, mainPanel;
     JPanel Dashboard, FindStu, AddStu, AddTeacher, FindTeacher, Course, Grades, Logout,Deletion;
     JLabel pageMainTitle, l2, l3, l4, l5, l6, DashLab1, StuInfo10, AddStuLab10, CourseLab3, DashLab2, StuLab1, StuLab2, StuLab3, StuLab4, StuLab5, StuLab6, StuLab7, StuLab8, StuLab9, StuLab10, StuLab11, StuInfo1, StuInfo2, StuInfo3, StuInfo4, StuInfo5, StuInfo6, StuInfo7, StuInfo8, StuInfo9, TeacherLab1, TeacherLab2, TeacherLab3, TeacherLab4, TeacherLab5, TeacherLab6, TeacherLab7, TeacherLab8, TeacherLab9, TL10, AddStuLab1, AddStuLab2, AddStuLab3, AddStuLab4, AddStuLab5, AddStuLab6, AddStuLab7, AddStuLab8, AddStuLab9, TeacherInfo1, TeacherInfo2, TeacherInfo3, TeacherInfo4, TeacherInfo5, TeacherInfo6, TeacherInfo7, TeacherInfo8, GradeLab1, GradeLab2, GradeLab3, AddTeacherLab1, AddTeacherLab2, AddTeacherLab3, AddTeacherLab4, AddTeacherLab5, AddTeacherLab6, AddTeacherLab7, AddTeacherLab8, CourseLab1, CourseLab2,DeleteLabel;
     JRadioButton GradeRadioBtn1, GradeRadioBtn2;
     static JLabel TeacherNum, StuNum;
     JTextField StuText, TT10, AddStuText1, CourseText3, AddStuText2, AddStuText10, AddStuText3, AddStuText4, AddStuText5, AddStuText6, AddStuText7, AddStuText8, AddStuText9, TeacherText, GradeText1, GradeText2, GradeText3, AddTeacherText1, AddTeacherText2, AddTeacherText3, AddTeacherText4, AddTeacherText5, AddTeacherText6, AddTeacherText7, AddTeacherText8, CourseText1, CourseText2,DeleteText;
     JCheckBox StudentCheck, TeacherCheck;
     ButtonGroup GroupBtn, deleteGroup;
//==============================================================================================================================================================

    public AdminPage() {

        this.setTitle("Admin Page");
        this.setResizable(false);
        this.setSize(1000, 600);
        this.setVisible(true);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
//==============================================================================================================================================================
        //Initializaion 
        DashboardPage = new JButton("Dashboard");
        FindStudentPage = new JButton("Find Students");
        AddStudentPage = new JButton("Add Students");
        FindTeacherPage = new JButton("Find Teachers");
        AddTeacherPage = new JButton("Add Teachers");
        CoursePage = new JButton("Course");
        GradePage = new JButton("Grades");
        DeletionPage = new JButton("Deletion");
        pageMainTitle = new JLabel("- Admin Page -");
        LogoutBtn = new JButton("Logout");
        mainPanel = new JPanel(cardLayout);
        Dashboard = new JPanel();
        FindStu = new JPanel();
        AddStu = new JPanel();
        AddTeacher = new JPanel();
        FindTeacher = new JPanel();
        Course = new JPanel();
        Grades = new JPanel();
        Deletion = new JPanel();
        Logout = new JPanel();
        sidebar = new JPanel();
        header = new JPanel();
        cardLayout = new CardLayout();
//==============================================================================================================================================================
        // Sidebar
        ImageIcon side = new ImageIcon("side.jpg");
        final Image Side = side.getImage();

        sidebar = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Side, 0, 0, getWidth(), getHeight(), this);
            }
        };

        sidebar.setLayout(null);
        this.add(sidebar);
        sidebar.setBounds(0, 80, 200, 600);
        sidebar.add(DashboardPage);
        DashboardPage.setBounds(5, 30, 190, 40);
        sidebar.add(FindStudentPage);
        FindStudentPage.setBounds(5, 75, 190, 40);
        sidebar.add(AddStudentPage);
        AddStudentPage.setBounds(5, 120, 190, 40);
        sidebar.add(FindTeacherPage);
        FindTeacherPage.setBounds(5, 165, 190, 40);
        sidebar.add(AddTeacherPage);
        AddTeacherPage.setBounds(5, 210, 190, 40);
        sidebar.add(CoursePage);
        CoursePage.setBounds(5, 255, 190, 40);
        sidebar.add(GradePage);
        GradePage.setBounds(5, 300, 190, 40);
        sidebar.add(DeletionPage);
        DeletionPage.setBounds(5, 345, 190, 40);
        sidebar.add(LogoutBtn);
        LogoutBtn.setBounds(5, 435, 190, 40);
        LogoutBtn.setBackground(Color.RED);
        LogoutBtn.setForeground(Color.WHITE);
//==============================================================================================================================================================
        //Header  
        ImageIcon head = new ImageIcon("head.jpg");
        final Image Head = head.getImage();

        header = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Head, 0, 0, getWidth(), getHeight(), this);
            }
        };

        header.setLayout(null);
        this.add(header);
        header.add(pageMainTitle);
        pageMainTitle.setBounds(400, 35, 600, 25);
        pageMainTitle.setFont(new Font("Arial", Font.BOLD, 25));
        pageMainTitle.setForeground(Color.WHITE);
        header.setBounds(0, 0, 1000, 80);
//==============================================================================================================================================================        

        // Main Panel with CardLayout    
        mainPanel.setLayout(cardLayout);
        mainPanel.setBounds(200, 80, 800, 520);
        this.add(mainPanel);
//==============================================================================================================================================================
        // Pages

        //Dashboard page    
        ImageIcon dash = new ImageIcon("back.jpg");
        final Image dashboard = dash.getImage();

        Dashboard = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(dashboard, 0, 0, getWidth(), getHeight(), this);
            }
        };

        Dashboard.setLayout(null);
        JLabel dashLabel = new JLabel("Welcome to the Dashboard!");
        dashLabel.setFont(new Font("Arial", Font.BOLD, 20));
        dashLabel.setBounds(20, 20, 300, 30);
        dashLabel.setForeground(Color.orange);

        DashLab1 = new JLabel("Number of studends");
        DashLab1.setBounds(60, 50, 350, 120);
        DashLab1.setFont(new Font(null, Font.BOLD, 22));
        DashLab1.setForeground(Color.WHITE);

        DashLab2 = new JLabel("Number of Teachers");
        DashLab2.setBounds(400, 50, 350, 120);
        DashLab2.setFont(new Font(null, Font.BOLD, 22));
        DashLab2.setForeground(Color.WHITE);

        StuNum = new JLabel();
        StuNum.setBounds(150, 100, 100, 130);
        StuNum.setBackground(Color.WHITE);
        StuNum.setFont(new Font(null, Font.BOLD, 30));
        StuNum.setForeground(Color.YELLOW);

        TeacherNum = new JLabel();
        TeacherNum.setBounds(500, 100, 100, 130);
        TeacherNum.setBackground(Color.WHITE);
        TeacherNum.setFont(new Font(null, Font.BOLD, 30));
        TeacherNum.setForeground(Color.YELLOW);


        Dashboard.add(dashLabel);
        Dashboard.add(DashLab1);
        Dashboard.add(DashLab2);
        Dashboard.add(StuNum);
        Dashboard.add(TeacherNum);
//==============================================================================================================================================================
        // Find Student page
        ImageIcon FindS = new ImageIcon("back.jpg");
        final Image StuP = FindS.getImage();

        FindStu = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(StuP, 0, 0, getWidth(), getHeight(), this);
            }
        };

        FindStu.setLayout(null);
        JLabel studLabel = new JLabel("Find Students Page");
        studLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        StuSearchBtn = new JButton("search");
        StuSearchBtn.setBounds(460, 40, 100, 30);
        StuSearchBtn.setFont(new Font("Arial", Font.BOLD, 15));

        StuLab1 = new JLabel("Student ID :");
        StuLab1.setBounds(150, 40, 200, 30);
        StuLab1.setFont(new Font("Arial", Font.BOLD, 15));
        studLabel.setBounds(20, 10, 300, 30);

        StuText = new JTextField();
        StuText.setBounds(240, 40, 200, 30);
        StuText.setFont(new Font(null, Font.BOLD, 15));
        StuText.setBorder(null);

        StuLab2 = new JLabel("ID :");
        StuLab2.setBounds(30, 100, 100, 40);
        StuLab2.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo1 = new JLabel();
        StuInfo1.setBounds(180, 105, 320, 30);
        StuInfo1.setFont(new Font(null, Font.BOLD, 18));
        StuInfo1.setBorder(null);

        StuLab3 = new JLabel("Full name :");
        StuLab3.setBounds(30, 150, 150, 40);
        StuLab3.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo2 = new JLabel();
        StuInfo2.setBounds(180, 155, 320, 30);
        StuInfo2.setFont(new Font(null, Font.BOLD, 18));
        StuInfo2.setBorder(null);

        StuLab4 = new JLabel("Stu mobile :");
        StuLab4.setBounds(30, 200, 150, 40);
        StuLab4.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo3 = new JLabel();
        StuInfo3.setBounds(180, 205, 320, 30);
        StuInfo3.setFont(new Font(null, Font.BOLD, 18));
        StuInfo3.setBorder(null);

        StuLab5 = new JLabel("Parent mobile :");
        StuLab5.setBounds(30, 250, 150, 40);
        StuLab5.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo4 = new JLabel();
        StuInfo4.setBounds(180, 255, 320, 30);
        StuInfo4.setFont(new Font(null, Font.BOLD, 18));
        StuInfo4.setBorder(null);

        StuLab6 = new JLabel("Stu e-mail :");
        StuLab6.setBounds(30, 300, 150, 40);
        StuLab6.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo5 = new JLabel();
        StuInfo5.setBounds(180, 305, 320, 30);
        StuInfo5.setFont(new Font(null, Font.BOLD, 18));
        StuInfo5.setBorder(null);

        StuLab7 = new JLabel("Stu level :");
        StuLab7.setBounds(30, 350, 150, 40);
        StuLab7.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo6 = new JLabel();
        StuInfo6.setBounds(180, 355, 320, 30);
        StuInfo6.setFont(new Font(null, Font.BOLD, 18));
        StuInfo6.setBorder(null);

        StuLab8 = new JLabel("Stu address:");
        StuLab8.setBounds(30, 400, 150, 40);
        StuLab8.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo7 = new JLabel();
        StuInfo7.setBounds(180, 405, 320, 30);
        StuInfo7.setFont(new Font(null, Font.BOLD, 18));
        StuInfo7.setBorder(null);

        StuLab9 = new JLabel("Age :");
        StuLab9.setBounds(550, 100, 100, 40);
        StuLab9.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo8 = new JLabel();
        StuInfo8.setBounds(630, 105, 100, 30);
        StuInfo8.setFont(new Font(null, Font.BOLD, 18));
        StuInfo8.setBorder(null);

        StuLab10 = new JLabel("Gender :");
        StuLab10.setBounds(550, 150, 100, 40);
        StuLab10.setFont(new Font("Arial", Font.BOLD, 17));

        StuInfo9 = new JLabel();
        StuInfo9.setBounds(630, 155, 100, 30);
        StuInfo9.setFont(new Font(null, Font.BOLD, 18));
        StuInfo9.setBorder(null);

        studLabel.setForeground(Color.ORANGE);
        StuLab1.setForeground(Color.WHITE);
        StuLab2.setForeground(Color.WHITE);
        StuLab3.setForeground(Color.WHITE);
        StuLab4.setForeground(Color.WHITE);
        StuLab5.setForeground(Color.WHITE);
        StuLab6.setForeground(Color.WHITE);
        StuLab7.setForeground(Color.WHITE);
        StuLab8.setForeground(Color.WHITE);
        StuLab9.setForeground(Color.WHITE);
        StuLab10.setForeground(Color.WHITE);

        StuInfo1.setForeground(Color.yellow);
        StuInfo2.setForeground(Color.yellow);
        StuInfo3.setForeground(Color.yellow);
        StuInfo4.setForeground(Color.yellow);
        StuInfo5.setForeground(Color.yellow);
        StuInfo6.setForeground(Color.yellow);
        StuInfo7.setForeground(Color.yellow);
        StuInfo8.setForeground(Color.yellow);
        StuInfo9.setForeground(Color.yellow);

        FindStu.add(StuSearchBtn);
        FindStu.add(StuText);
        FindStu.add(StuInfo1);
        FindStu.add(StuInfo2);
        FindStu.add(StuInfo3);
        FindStu.add(StuInfo4);
        FindStu.add(StuInfo5);
        FindStu.add(StuInfo6);
        FindStu.add(StuInfo7);
        FindStu.add(StuInfo8);
        FindStu.add(StuInfo9);
        FindStu.add(StuLab1);
        FindStu.add(StuLab2);
        FindStu.add(StuLab3);
        FindStu.add(StuLab4);
        FindStu.add(StuLab5);
        FindStu.add(StuLab6);
        FindStu.add(StuLab7);
        FindStu.add(StuLab8);
        FindStu.add(StuLab9);
        FindStu.add(StuLab10);
        FindStu.add(studLabel);
//==============================================================================================================================================================
        //Add Studends page
        ImageIcon AddS = new ImageIcon("back.jpg");
        final Image Adds = AddS.getImage();

        AddStu = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Adds, 0, 0, getWidth(), getHeight(), this);
            }
        };

        AddStu.setLayout(null);
        JLabel addStu = new JLabel("Add Studends page");
        addStu.setFont(new Font("Arial", Font.PLAIN, 20));
        addStu.setBounds(20, 20, 300, 30);
        AddStu.add(addStu);
        addStu.setForeground(Color.ORANGE);

        AddStuBtn = new JButton("Add Student");
        AddStuBtn.setBounds(280, 430, 170, 30);
        AddStuBtn.setFont(new Font("Arial", Font.BOLD, 15));

        AddStuLab1 = new JLabel("Full name :");
        AddStuLab1.setBounds(30, 80, 100, 40);
        AddStuLab1.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText1 = new JTextField();
        AddStuText1.setBounds(180, 85, 320, 30);
        AddStuText1.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab2 = new JLabel("ID :");
        AddStuLab2.setBounds(30, 130, 150, 40);
        AddStuLab2.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText2 = new JTextField();
        AddStuText2.setBounds(180, 135, 320, 30);
        AddStuText2.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab3 = new JLabel("Email :");
        AddStuLab3.setBounds(30, 180, 150, 40);
        AddStuLab3.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText3 = new JTextField();
        AddStuText3.setBounds(180, 185, 320, 30);
        AddStuText3.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab4 = new JLabel("Password :");
        AddStuLab4.setBounds(30, 230, 150, 40);
        AddStuLab4.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText4 = new JTextField();
        AddStuText4.setBounds(180, 235, 320, 30);
        AddStuText4.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab5 = new JLabel("Stu Mobile :");
        AddStuLab5.setBounds(30, 280, 150, 40);
        AddStuLab5.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText5 = new JTextField();
        AddStuText5.setBounds(180, 285, 320, 30);
        AddStuText5.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab6 = new JLabel("Parent Mobile :");
        AddStuLab6.setBounds(30, 330, 150, 40);
        AddStuLab6.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText6 = new JTextField();
        AddStuText6.setBounds(180, 335, 320, 30);
        AddStuText6.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab7 = new JLabel("Level:");
        AddStuLab7.setBounds(30, 380, 150, 40);
        AddStuLab7.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText7 = new JTextField();
        AddStuText7.setBounds(180, 385, 320, 30);
        AddStuText7.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab8 = new JLabel("Address :");
        AddStuLab8.setBounds(550, 80, 100, 40);
        AddStuLab8.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText8 = new JTextField();
        AddStuText8.setBounds(630, 85, 100, 30);
        AddStuText8.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab9 = new JLabel("Age :");
        AddStuLab9.setBounds(550, 130, 100, 40);
        AddStuLab9.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText9 = new JTextField();
        AddStuText9.setBounds(630, 135, 100, 30);
        AddStuText9.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab10 = new JLabel("Gender :");
        AddStuLab10.setBounds(550, 180, 100, 40);
        AddStuLab10.setFont(new Font("Arial", Font.BOLD, 17));

        AddStuText10 = new JTextField();
        AddStuText10.setBounds(630, 185, 100, 30);
        AddStuText10.setFont(new Font(null, Font.BOLD, 15));

        AddStuLab1.setForeground(Color.WHITE);
        AddStuLab2.setForeground(Color.WHITE);
        AddStuLab3.setForeground(Color.WHITE);
        AddStuLab4.setForeground(Color.WHITE);
        AddStuLab5.setForeground(Color.WHITE);
        AddStuLab6.setForeground(Color.WHITE);
        AddStuLab7.setForeground(Color.WHITE);
        AddStuLab8.setForeground(Color.WHITE);
        AddStuLab9.setForeground(Color.WHITE);
        AddStuLab10.setForeground(Color.WHITE);

        AddStu.add(AddStuBtn);
        AddStu.add(AddStuText1);
        AddStu.add(AddStuText2);
        AddStu.add(AddStuText3);
        AddStu.add(AddStuText4);
        AddStu.add(AddStuText5);
        AddStu.add(AddStuText6);
        AddStu.add(AddStuText7);
        AddStu.add(AddStuText8);
        AddStu.add(AddStuText9);
        AddStu.add(AddStuText10);
        AddStu.add(AddStuLab1);
        AddStu.add(AddStuLab2);
        AddStu.add(AddStuLab3);
        AddStu.add(AddStuLab4);
        AddStu.add(AddStuLab5);
        AddStu.add(AddStuLab6);
        AddStu.add(AddStuLab7);
        AddStu.add(AddStuLab8);
        AddStu.add(AddStuLab9);
        AddStu.add(AddStuLab10);
//==============================================================================================================================================================      
        //Find Teacher page
        ImageIcon FindT = new ImageIcon("back.jpg");
        final Image Tpage = FindT.getImage();

        FindTeacher = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Tpage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        FindTeacher.setLayout(null);
        JLabel Fteacher = new JLabel("Find Teachers page");
        Fteacher.setFont(new Font("Arial", Font.PLAIN, 20));
        Fteacher.setBounds(20, 20, 300, 30);
        FindTeacher.add(Fteacher);
        Fteacher.setForeground(Color.ORANGE);

        TeacherLab1 = new JLabel("Teacher ID :");
        TeacherLab2 = new JLabel("Full name :");
        TeacherLab3 = new JLabel("Phone :");
        TeacherLab4 = new JLabel("E-mail :");
        TeacherLab5 = new JLabel("Address :");
        TeacherLab6 = new JLabel("Age :");
        TeacherLab7 = new JLabel("Gender :");
        TeacherLab8 = new JLabel("Course code :");
        TeacherLab9 = new JLabel("ID :");
        TeacherText = new JTextField();
        TeacherInfo1 = new JLabel();
        TeacherInfo2 = new JLabel();
        TeacherInfo3 = new JLabel();
        TeacherInfo4 = new JLabel();
        TeacherInfo5 = new JLabel();
        TeacherInfo6 = new JLabel();
        TeacherInfo7 = new JLabel();
        TeacherInfo8 = new JLabel();

        TeacherLab1.setForeground(Color.WHITE);
        TeacherLab2.setForeground(Color.WHITE);
        TeacherLab3.setForeground(Color.WHITE);
        TeacherLab4.setForeground(Color.WHITE);
        TeacherLab5.setForeground(Color.WHITE);
        TeacherLab6.setForeground(Color.WHITE);
        TeacherLab7.setForeground(Color.WHITE);
        TeacherLab8.setForeground(Color.WHITE);
        TeacherLab9.setForeground(Color.WHITE);

        TeacherInfo1.setForeground(Color.YELLOW);
        TeacherInfo2.setForeground(Color.YELLOW);
        TeacherInfo3.setForeground(Color.YELLOW);
        TeacherInfo4.setForeground(Color.YELLOW);
        TeacherInfo5.setForeground(Color.YELLOW);
        TeacherInfo6.setForeground(Color.YELLOW);
        TeacherInfo7.setForeground(Color.YELLOW);
        TeacherInfo8.setForeground(Color.YELLOW);

        TeacherInfo1.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo2.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo3.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo4.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo5.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo6.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo7.setFont(new Font(null, Font.BOLD, 17));
        TeacherInfo8.setFont(new Font(null, Font.BOLD, 17));

        FindTeacherBtn = new JButton("Search");

        FindTeacher.setLayout(null);

        TeacherLab1.setLayout(null);
        TeacherLab1.setBounds(120, 50, 300, 25);
        TeacherLab1.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab1);
        TeacherText.setBounds(220, 50, 200, 25);
        FindTeacher.add(TeacherText);
        FindTeacherBtn.setBounds(450, 50, 100, 25);
        FindTeacher.add(FindTeacherBtn);

        TeacherLab9.setBounds(30, 90, 300, 25);
        TeacherLab9.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab9);
        TeacherInfo8.setBounds(160, 90, 300, 25);
        FindTeacher.add(TeacherInfo8);

        TeacherLab2.setBounds(30, 130, 300, 25);
        TeacherLab2.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab2);
        TeacherInfo1.setBounds(160, 130, 300, 25);
        FindTeacher.add(TeacherInfo1);

        TeacherLab3.setBounds(30, 170, 300, 25);
        TeacherLab3.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab3);
        TeacherInfo2.setBounds(160, 170, 300, 25);
        FindTeacher.add(TeacherInfo2);

        TeacherLab4.setBounds(30, 210, 300, 25);
        TeacherLab4.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab4);
        TeacherInfo3.setBounds(160, 210, 300, 25);
        FindTeacher.add(TeacherInfo3);

        TeacherLab5.setBounds(30, 250, 300, 25);
        TeacherLab5.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab5);
        TeacherInfo4.setBounds(160, 250, 300, 25);
        FindTeacher.add(TeacherInfo4);

        TeacherLab6.setBounds(30, 290, 300, 25);
        TeacherLab6.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab6);
        TeacherInfo5.setBounds(160, 290, 300, 25);
        FindTeacher.add(TeacherInfo5);

        TeacherLab7.setBounds(30, 330, 300, 25);
        TeacherLab7.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab7);
        TeacherInfo6.setBounds(160, 330, 300, 25);
        FindTeacher.add(TeacherInfo6);

        TeacherLab8.setBounds(30, 370, 300, 25);
        TeacherLab8.setFont(new Font(null, Font.BOLD, 15));
        FindTeacher.add(TeacherLab8);
        TeacherInfo7.setBounds(160, 370, 300, 25);
        FindTeacher.add(TeacherInfo7);
//==============================================================================================================================================================
        //Add Teachers page
        ImageIcon addT = new ImageIcon("back.jpg");
        final Image addt = addT.getImage();

        AddTeacher = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(addt, 0, 0, getWidth(), getHeight(), this);
            }
        };
        AddTeacher.setLayout(null);
        JLabel addTeacher = new JLabel("Add Teachers Page ");
        addTeacher.setFont(new Font("Arial", Font.PLAIN, 20));
        addTeacher.setBounds(20, 20, 300, 30);
        AddTeacher.add(addTeacher);
        addTeacher.setForeground(Color.ORANGE);

        AddTeacherLab1 = new JLabel("ID :");
        AddTeacherLab2 = new JLabel("Full name :");
        AddTeacherLab3 = new JLabel("Phone :");
        AddTeacherLab4 = new JLabel("Prof E-mail :");
        AddTeacherLab5 = new JLabel("Prof address :");
        AddTeacherLab6 = new JLabel("Age :");
        AddTeacherLab7 = new JLabel("Gender :");
        AddTeacherLab8 = new JLabel("course :");

        AddTeacherText1 = new JTextField();
        AddTeacherText2 = new JTextField();
        AddTeacherText3 = new JTextField();
        AddTeacherText4 = new JTextField();
        AddTeacherText5 = new JTextField();
        AddTeacherText6 = new JTextField();
        AddTeacherText7 = new JTextField();
        AddTeacherText8 = new JTextField();

        AddTeacherLab1.setForeground(Color.WHITE);
        AddTeacherLab2.setForeground(Color.WHITE);
        AddTeacherLab3.setForeground(Color.WHITE);
        AddTeacherLab4.setForeground(Color.WHITE);
        AddTeacherLab5.setForeground(Color.WHITE);
        AddTeacherLab6.setForeground(Color.WHITE);
        AddTeacherLab7.setForeground(Color.WHITE);
        AddTeacherLab8.setForeground(Color.WHITE);

        AddTeacherBtn = new JButton("Add Teacher");

        AddTeacherLab1.setLayout(null);
        AddTeacherLab1.setBounds(30, 50, 300, 25);
        AddTeacherLab1.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab1);
        AddTeacherText1.setBounds(220, 50, 200, 25);
        AddTeacher.add(AddTeacherText1);

        AddTeacherBtn.setBounds(250, 380, 130, 25);
        AddTeacher.add(AddTeacherBtn);

        AddTeacherLab2.setLayout(null);
        AddTeacherLab2.setBounds(30, 90, 300, 25);
        AddTeacherLab2.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab2);
        AddTeacherText2.setBounds(220, 90, 200, 25);
        AddTeacher.add(AddTeacherText2);

        AddTeacherLab3.setLayout(null);
        AddTeacherLab3.setBounds(30, 130, 300, 25);
        AddTeacherLab3.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab3);
        AddTeacherText3.setBounds(220, 130, 200, 25);
        AddTeacher.add(AddTeacherText3);

        AddTeacherLab4.setLayout(null);
        AddTeacherLab4.setBounds(30, 170, 300, 25);
        AddTeacherLab4.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab4);
        AddTeacherText4.setBounds(220, 170, 200, 25);
        AddTeacher.add(AddTeacherText4);

        AddTeacherLab5.setLayout(null);
        AddTeacherLab5.setBounds(30, 210, 300, 25);
        AddTeacherLab5.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab5);
        AddTeacherText5.setBounds(220, 210, 200, 25);
        AddTeacher.add(AddTeacherText5);

        AddTeacherLab6.setLayout(null);
        AddTeacherLab6.setBounds(30, 250, 300, 25);
        AddTeacherLab6.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab6);
        AddTeacherText6.setBounds(220, 250, 200, 25);
        AddTeacher.add(AddTeacherText6);

        AddTeacherLab7.setLayout(null);
        AddTeacherLab7.setBounds(30, 290, 300, 25);
        AddTeacherLab7.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab7);
        AddTeacherText7.setBounds(220, 290, 200, 25);
        AddTeacher.add(AddTeacherText7);

        AddTeacherLab8.setLayout(null);
        AddTeacherLab8.setBounds(30, 330, 300, 25);
        AddTeacherLab8.setFont(new Font(null, Font.BOLD, 15));
        AddTeacher.add(AddTeacherLab8);
        AddTeacherText8.setBounds(220, 330, 200, 25);
        AddTeacher.add(AddTeacherText8);
//==============================================================================================================================================================
        //Course
        ImageIcon course = new ImageIcon("back.jpg");
        final Image courses = course.getImage();

        Course = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(courses, 0, 0, getWidth(), getHeight(), this);
            }
        };
        Course.setLayout(null);
        JLabel Gradlabel = new JLabel("Course Page");
        Gradlabel.setFont(new Font("Arial", Font.PLAIN, 20));
        Gradlabel.setBounds(20, 20, 300, 30);
        Course.add(Gradlabel);
        Gradlabel.setForeground(Color.ORANGE);

        CourseLab1 = new JLabel("Student ID");
        CourseLab1.setBounds(250, 50, 200, 50);
        CourseLab1.setFont(new Font(null, Font.BOLD, 20));
        CourseLab1.setForeground(Color.WHITE);

        CourseText1 = new JTextField();
        CourseText1.setBounds(400, 55, 250, 30);
        CourseText1.setFont(new Font(null, Font.BOLD, 15));
        CourseText1.setBorder(null);

        CourseLab2 = new JLabel("Course code");
        CourseLab2.setBounds(250, 130, 200, 50);
        CourseLab2.setFont(new Font(null, Font.BOLD, 20));
        CourseLab2.setForeground(Color.WHITE);

        CourseText2 = new JTextField();
        CourseText2.setBounds(400, 135, 250, 30);
        CourseText2.setFont(new Font(null, Font.BOLD, 15));
        CourseText2.setBorder(null);

        CourseLab3 = new JLabel("Course Name");
        CourseLab3.setBounds(250, 210, 200, 50);
        CourseLab3.setFont(new Font(null, Font.BOLD, 20));
        CourseLab3.setForeground(Color.WHITE);

        CourseText3 = new JTextField();
        CourseText3.setBounds(400, 215, 250, 30);
        CourseText3.setFont(new Font(null, Font.BOLD, 15));
        CourseText3.setBorder(null);

        CourseBtn = new JButton("Add course");
        CourseBtn.setFont(new Font(null, Font.BOLD, 18));
        CourseBtn.setBounds(440, 280, 150, 30);

        Course.add(CourseLab1);
        Course.add(CourseLab2);
        Course.add(CourseLab3);
        Course.add(CourseText1);
        Course.add(CourseText2);
        Course.add(CourseText3);
        Course.add(CourseBtn);
//==============================================================================================================================================================
        //Grades
        ImageIcon Grade = new ImageIcon("back.jpg");
        final Image Gradee = Grade.getImage();

        Grades = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Gradee, 0, 0, getWidth(), getHeight(), this);
            }
        };
        Grades.setLayout(null);
        JLabel grade = new JLabel("Grades Page");
        grade.setFont(new Font("Arial", Font.PLAIN, 20));
        grade.setBounds(20, 20, 300, 30);
        Grades.add(grade);
        grade.setForeground(Color.ORANGE);

        GradeLab1 = new JLabel("Student ID");
        GradeLab1.setBounds(250, 50, 200, 50);
        GradeLab1.setFont(new Font(null, Font.BOLD, 20));
        GradeLab1.setForeground(Color.WHITE);

        GradeText1 = new JTextField();
        GradeText1.setBounds(400, 55, 250, 30);
        GradeText1.setFont(new Font(null, Font.BOLD, 15));
        GradeText1.setBorder(null);

        GradeLab2 = new JLabel("Course code");
        GradeLab2.setBounds(250, 130, 200, 50);
        GradeLab2.setFont(new Font(null, Font.BOLD, 20));
        GradeLab2.setForeground(Color.WHITE);

        GradeText2 = new JTextField();
        GradeText2.setBounds(400, 135, 250, 30);
        GradeText2.setFont(new Font(null, Font.BOLD, 15));
        GradeText2.setBorder(null);

        GradeLab3 = new JLabel("Course grade");
        GradeLab3.setBounds(250, 210, 200, 50);
        GradeLab3.setFont(new Font(null, Font.BOLD, 20));
        GradeLab3.setForeground(Color.WHITE);

        GradeText3 = new JTextField();
        GradeText3.setBounds(400, 215, 250, 30);
        GradeText3.setFont(new Font(null, Font.BOLD, 15));
        GradeText3.setBorder(null);

        GradeRadioBtn1 = new JRadioButton("Midterm");
        GradeRadioBtn2 = new JRadioButton("Final");
        ButtonGroup GroupBtn = new ButtonGroup();
        GroupBtn.add(GradeRadioBtn1);
        GroupBtn.add(GradeRadioBtn2);
        GradeRadioBtn1.setBounds(420, 250, 100, 50);
        GradeRadioBtn2.setBounds(530, 250, 100, 50);
        GradeRadioBtn1.setOpaque(false);
        GradeRadioBtn2.setOpaque(false);
        GradeRadioBtn1.setForeground(Color.WHITE);
        GradeRadioBtn2.setForeground(Color.WHITE);

        GradeBtn1 = new JButton("Add");
        GradeBtn2 = new JButton("Update");

        GradeBtn1.setBounds(410, 310, 100, 30);
        GradeBtn2.setBounds(530, 310, 100, 30);
        GradeBtn1.setBounds(410, 310, 100, 30);
        GradeBtn2.setBounds(530, 310, 100, 30);

        Grades.add(GradeLab1);
        Grades.add(GradeLab2);
        Grades.add(GradeLab3);
        Grades.add(GradeRadioBtn1);
        Grades.add(GradeRadioBtn2);
        Grades.add(GradeText1);
        Grades.add(GradeText2);
        Grades.add(GradeText3);
        Grades.add(GradeBtn1);
        Grades.add(GradeBtn2);
//==============================================================================================================================================================
        //Deletion page
        ImageIcon Del = new ImageIcon("back.jpg");
        final Image del = Del.getImage();

        Deletion = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(del, 0, 0, getWidth(), getHeight(), this);
            }
        };
        Deletion.setLayout(null);
        JLabel deletionLabel = new JLabel("Deletion Page");
        deletionLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        deletionLabel.setBounds(20, 20, 300, 30);
        deletionLabel.setForeground(Color.ORANGE);
        Deletion.add(deletionLabel);

        DeleteLabel = new JLabel("Enter ID:");
        DeleteLabel.setBounds(250, 100, 200, 50);
        DeleteLabel.setFont(new Font(null, Font.BOLD, 20));
        DeleteLabel.setForeground(Color.WHITE);
        Deletion.add(DeleteLabel);

        DeleteText = new JTextField();
        DeleteText.setBounds(400, 110, 250, 30);
        DeleteText.setFont(new Font(null, Font.BOLD, 15));
        DeleteText.setBorder(null);
        Deletion.add(DeleteText);

        StudentCheck = new JCheckBox("Student");
        TeacherCheck = new JCheckBox("Teacher");
        deleteGroup = new ButtonGroup();
        deleteGroup.add(StudentCheck);
        deleteGroup.add(TeacherCheck);
        StudentCheck.setBounds(350, 170, 100, 30);
        TeacherCheck.setBounds(500, 170, 100, 30);
        StudentCheck.setOpaque(false);
        TeacherCheck.setOpaque(false);
        StudentCheck.setForeground(Color.WHITE);
        TeacherCheck.setForeground(Color.WHITE);
        StudentCheck.setFont(new Font(null, Font.BOLD, 15));
        TeacherCheck.setFont(new Font(null, Font.BOLD, 15));
        Deletion.add(StudentCheck);
        Deletion.add(TeacherCheck);

        DeleteBtn = new JButton("Delete");
        DeleteBtn.setBounds(400, 230, 170, 30);
//        DeleteBtn.setFont(new Font("Arial", Font.BOLD, 15));
//        DeleteBtn.setBackground(Color.white);
        DeleteBtn.setForeground(Color.black);
        Deletion.add(DeleteBtn);
        DeleteBtn.addActionListener(this);

        // Add pages to mainPanel
        mainPanel.add(Dashboard, "dashboard");
        mainPanel.add(FindStu, "Find students");
        mainPanel.add(AddStu, "Add students");
        mainPanel.add(FindTeacher, "Find Teachers");
        mainPanel.add(AddTeacher, "Add Teachers");
        mainPanel.add(Course, "Course");
        mainPanel.add(Grades, "Grades");
        mainPanel.add(Deletion, "Deletion");
        mainPanel.add(Logout, "Logout");

        // Action Buttons
        DashboardPage.addActionListener(this);
        FindStudentPage.addActionListener(this);
        AddStudentPage.addActionListener(this);
        FindTeacherPage.addActionListener(this);
        AddTeacherPage.addActionListener(this);
        CoursePage.addActionListener(this);
        GradePage.addActionListener(this);
        DeletionPage.addActionListener(this);
        LogoutBtn.addActionListener(this);
        AddTeacherBtn.addActionListener(this);
        FindTeacherBtn.addActionListener(this);
        AddStuBtn.addActionListener(this);
        StuSearchBtn.addActionListener(this);
        CourseBtn.addActionListener(this);
        GradeBtn1.addActionListener(this);
        GradeBtn2.addActionListener(this);
    }
//==============================================================================================================================================================
    //Buttons Actions

    @Override
    public void actionPerformed(ActionEvent e) {
        User userT = new Teacher();
        Teacher Teacher = new Teacher();

        User userS = new Student();
        Student student = new Student();
        Course courseobj = new Course();

        if (e.getSource() == DashboardPage) {
            cardLayout.show(mainPanel, "dashboard");
        } else if (e.getSource() == FindStudentPage) {
            cardLayout.show(mainPanel, "Find students");
        } else if (e.getSource() == AddStudentPage) {
            cardLayout.show(mainPanel, "Add students");
        } else if (e.getSource() == FindTeacherPage) {
            cardLayout.show(mainPanel, "Find Teachers");
        } else if (e.getSource() == AddTeacherPage) {
            cardLayout.show(mainPanel, "Add Teachers");
        } else if (e.getSource() == CoursePage) {
            cardLayout.show(mainPanel, "Course");
        } else if (e.getSource() == GradePage) {
            cardLayout.show(mainPanel, "Grades");
        } else if (e.getSource() == DeletionPage) {
            cardLayout.show(mainPanel, "Deletion");
        } //logout action
        else if (e.getSource() == LogoutBtn) {
            int logout = JOptionPane.showConfirmDialog(AdminPage.this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

            if (logout == JOptionPane.YES_OPTION) {
                this.setVisible(false);
                LoginPage login = new LoginPage();
                login.setVisible(true);
            }
        } //add teacher action
        else if (e.getSource() == AddTeacherBtn) {
             try {
                String id = AddTeacherText1.getText().trim();
                String fullName = AddTeacherText2.getText().trim();
                String mobile = AddTeacherText3.getText().trim();
                String email = AddTeacherText4.getText().trim();
                String address = AddTeacherText5.getText().trim();
                String ageText = AddTeacherText6.getText().trim();
                String gender = AddTeacherText7.getText().trim();
                String courseCode = AddTeacherText8.getText().trim();

                if (id.isEmpty() && fullName.isEmpty() && mobile.isEmpty() && email.isEmpty()&& address.isEmpty() && ageText.isEmpty() && gender.isEmpty() && courseCode.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No data was entered.");
                    return;
                }

                if (id.isEmpty() || fullName.isEmpty() || mobile.isEmpty() || email.isEmpty()|| address.isEmpty() || ageText.isEmpty() || gender.isEmpty() || courseCode.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }

                if (!email.contains("@gmail.com")) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                    return;
                }
              
                userT.setId(Integer.parseInt(id));
                Teacher.setFullName(fullName);
                Teacher.setTeacherMobile(mobile);
                Teacher.setEmail(email);
                Teacher.setAddress(address);
                Teacher.setAge(Integer.parseInt(ageText));
                Teacher.setGender(gender);
                Teacher.setCourseCode(courseCode);

                if (Database.AddTeacher(userT.getId(), Teacher.getFullName(), Teacher.getTeacherMobile(), Teacher.getEmail(), Teacher.getAddress(), Teacher.getAge(), Teacher.getGender(), Teacher.getCourseCode())) {
                    JOptionPane.showMessageDialog(null, "Teacher added successfully.");

                    AddTeacherText1.setText("");
                    AddTeacherText2.setText("");
                    AddTeacherText3.setText("");
                    AddTeacherText4.setText("");
                    AddTeacherText5.setText("");
                    AddTeacherText6.setText("");
                    AddTeacherText7.setText("");
                    AddTeacherText8.setText("");
                    
                    Database.TeacherCount(TeacherNum); 
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Course code does not exist or insert failed.");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "ID and Age must be valid integers.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
            }
        } //find teacher action
        else if (e.getSource() == FindTeacherBtn) {
            try {
                userT.setId(Integer.parseInt(TeacherText.getText().trim()));
                Database.FindTeacher(userT.getId(), TeacherInfo8, TeacherInfo1, TeacherInfo2, TeacherInfo3, TeacherInfo4, TeacherInfo5, TeacherInfo6, TeacherInfo7);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number for ID.");
            }

        } //add student action
        else if (e.getSource() == AddStuBtn) {
             try {
                String id = AddStuText2.getText().trim();
                String username = AddStuText1.getText().trim();
                String email = AddStuText3.getText().trim();
                String password = AddStuText4.getText().trim();
                String stuMobile = AddStuText5.getText().trim();
                String parentMobile = AddStuText6.getText().trim();
                String level = AddStuText7.getText().trim();
                String address = AddStuText8.getText().trim();
                String ageText = AddStuText9.getText().trim();
                String gender = AddStuText10.getText().trim();

                if (id.isEmpty() && username.isEmpty() && email.isEmpty() && password.isEmpty()&& stuMobile.isEmpty() && parentMobile.isEmpty() && level.isEmpty()&& address.isEmpty() && ageText.isEmpty() && gender.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No data was entered.");
                    return;
                }

                if (id.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty() || stuMobile.isEmpty() || parentMobile.isEmpty() || level.isEmpty() || address.isEmpty() || ageText.isEmpty() || gender.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }

                if (!email.contains("@gmail.com")) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                    return;
                }

                userS.setId(Integer.parseInt(id));
                userS.setUsername(username);
                student.setEmial(email);
                userS.setPassword(password);
                student.setStuMobile(stuMobile);
                student.setParentMobile(parentMobile);
                student.setLevel(level);
                student.setAddress(address);
                student.setAge(Integer.parseInt(ageText));
                student.setGender(gender);

                Database.AddStu(userS.getUsername(), userS.getId(), student.getEmial(), userS.getPassword(), student.getStuMobile(), student.getParentMobile(), student.getLevel(), student.getAddress(), student.getAge(), student.getGender());

                AddStuText1.setText("");
                AddStuText2.setText("");
                AddStuText3.setText("");
                AddStuText4.setText("");
                AddStuText5.setText("");
                AddStuText6.setText("");
                AddStuText7.setText("");
                AddStuText8.setText("");
                AddStuText9.setText("");
                AddStuText10.setText("");
                
                Database.StuCount(StuNum);

               
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for ID and age.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
            }

        } // search student action
        else if (e.getSource() == StuSearchBtn) {
            String id = StuText.getText().trim();

            if (!id.isEmpty()) {
                try {
                    userS.setId(Integer.parseInt(id));

                    Database.GetStudentById(userS.getId(), StuInfo1, StuInfo2, StuInfo3, StuInfo4, StuInfo5, StuInfo6, StuInfo7, StuInfo8, StuInfo9);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number for ID.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a student ID.");
            }
        } //course mangment action
        else if (e.getSource() == CourseBtn) {
            String studentId = CourseText1.getText().trim();
            String courseId = CourseText2.getText().trim();
            String courseName = CourseText3.getText().trim();

            if (studentId.isEmpty() || courseId.isEmpty() || courseName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all fields");
                return;
            }

            try {
                userS.setId(Integer.parseInt(studentId));
                courseobj.setCourseId(courseId);
                courseobj.setCourseName(courseName);

                Database.addCourse(userS.getId(), courseobj.getCourseId(), courseobj.getCourseName());
                CourseText1.setText("");
                CourseText2.setText("");
                CourseText3.setText("");
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number for Student ID.");
            }
        } //add grade action
        else if (e.getSource() == GradeBtn1) {
            try {
                userS.setId(Integer.parseInt(GradeText1.getText().trim()));
                courseobj.setCourseId(GradeText2.getText().trim());
                courseobj.setGrade(Double.parseDouble(GradeText3.getText().trim()));
                if (GradeRadioBtn1.isSelected()) {

                    if (Database.MidtermGrade(userS.getId(), courseobj.getCourseId(), courseobj.getGrade())) {
                        JOptionPane.showMessageDialog(null, "Midterm grade added successfully.");
                        GradeText1.setText("");
                        GradeText2.setText("");
                        GradeText3.setText("");
                    }
                } else if (GradeRadioBtn2.isSelected()) {

                    if (Database.FinalGrade(userS.getId(), courseobj.getCourseId(), courseobj.getGrade())) {
                        JOptionPane.showMessageDialog(null, "Final grade added successfully.");
                        GradeText1.setText("");
                        GradeText2.setText("");
                        GradeText3.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select either Midterm or Final grade type");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for ID and grade");
            }

        }  //update grade action
        else if (e.getSource() == GradeBtn2) {
            try {
                userS.setId(Integer.parseInt(GradeText1.getText().trim()));
                courseobj.setCourseId(GradeText2.getText().trim());
                courseobj.setGrade(Double.parseDouble(GradeText3.getText().trim()));
                if (GradeRadioBtn1.isSelected()) {

                    if (Database.MidtermGrade(userS.getId(), courseobj.getCourseId(), courseobj.getGrade())) {
                        JOptionPane.showMessageDialog(null, "Midterm grade updated successfully.");
                        GradeText1.setText("");
                        GradeText2.setText("");
                        GradeText3.setText("");
                    }
                } else if (GradeRadioBtn2.isSelected()) {

                    if (Database.FinalGrade(userS.getId(), courseobj.getCourseId(), courseobj.getGrade())) {
                        JOptionPane.showMessageDialog(null, "Final grade updated successfully.");
                        GradeText1.setText("");
                        GradeText2.setText("");
                        GradeText3.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select either Midterm or Final grade type");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for ID and grade");
            }

        } else if (e.getSource() == DeleteBtn) {
            try {
                String idText = DeleteText.getText().trim();
                
                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter an ID.");
                    return;
                }

                int id = Integer.parseInt(idText);

                if (!StudentCheck.isSelected() && !TeacherCheck.isSelected()) {
                    JOptionPane.showMessageDialog(null, "Please select either Student or Teacher.");
                    return;
                }

                if (StudentCheck.isSelected()) {
                    if (Database.DeleteStudent(id)) {
                        JOptionPane.showMessageDialog(null, "Student deleted successfully.");
                        DeleteText.setText("");
                        deleteGroup.clearSelection();
                        Database.StuCount(StuNum);  
                    }
                } else if (TeacherCheck.isSelected()) {
                    if (Database.DeleteTeacher(id)) {
                        JOptionPane.showMessageDialog(null, "Teacher deleted successfully.");
                        DeleteText.setText("");
                        deleteGroup.clearSelection();
                        Database.TeacherCount(TeacherNum);  
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number for ID.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
            }
        }

    }
}
