package projectoop;
//==============================================================================================================================================================

public class Course {

    private String courseId;
    private String courseName;
    private double grade;
//==============================================================================================================================================================

    public Course() {
    }

    public Course(String courseId) {
        this.courseId = courseId;
    }
//==============================================================================================================================================================

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

}
