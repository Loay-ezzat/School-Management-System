package projectoop;
//==============================================================================================================================================================

import java.sql.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
//==============================================================================================================================================================

public class Database extends JFrame {

    static Connection con = null;
//==============================================================================================================================================================

    public static Connection DBC() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:SM_DB.db");

    }
//==============================================================================================================================================================
    //student counter

    public static void StuCount(JLabel counter) {
        String sql = "SELECT COUNT(*) AS total FROM Students";
        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                counter.setText(rs.getString("total"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
    }
//==============================================================================================================================================================
    //teacher counter

    public static void TeacherCount(JLabel counter) {
        String sql = "SELECT COUNT(*) AS total FROM Teachers";
        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                counter.setText(rs.getString("total"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
    }
    //==============================================================================================================================================================
    //student login

    public static boolean StdLogin(String username, String password) {
        String sql = "SELECT * FROM Students WHERE ID = ? AND Password = ?";
        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Login Successful!");
                User Stu = new Student();
                Stu.displayFrame();
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
        return false;

    }
    //==============================================================================================================================================================
    //admin login

    public static boolean AdminLogin(String username, String password) {
        String sql = "SELECT * FROM Admins WHERE Username = ? AND Password = ?";
        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Login Successful!");
                User admin = new Admin();
                admin.displayFrame();
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
        return false;
    }
    //==============================================================================================================================================================
    //add teacher

    public static boolean AddTeacher(int ID, String FullName, String TeacherMobile, String Email, String Address, int Age, String Gender, String CourseCode) {
        String courseSql = "SELECT * FROM StudentCourses WHERE course_id = ?";
        String addTeacherSql = "INSERT INTO Teachers (ID, FullName, TeacherMobile, Email, Address, Age, Gender, CourseCode) VALUES (?,?,?,?,?,?,?,?)";

        try (Connection con = DBC()) {
            
            PreparedStatement pst1 = con.prepareStatement(courseSql);
            pst1.setString(1, CourseCode);
            ResultSet rs = pst1.executeQuery();

            if (!rs.next()) {
                return false;  
            }
          
            PreparedStatement pst = con.prepareStatement(addTeacherSql);
            pst.setInt(1, ID);
            pst.setString(2, FullName);
            pst.setString(3, TeacherMobile);
            pst.setString(4, Email);
            pst.setString(5, Address);
            pst.setInt(6, Age);
            pst.setString(7, Gender);
            pst.setString(8, CourseCode);
           int rs1=pst.executeUpdate();
            return rs1>0; 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            return false;
        }
    }
//==============================================================================================================================================================
//find teacher

    public static void FindTeacher(int ID,JLabel idLabel,JLabel FullName,JLabel TeacherMobile,JLabel Email,JLabel Address,JLabel Age,JLabel Gender,JLabel courseLabel) {

        String sql = "SELECT * FROM Teachers WHERE ID = ?";

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, ID);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                idLabel.setText(rs.getString("ID"));
                FullName.setText(rs.getString("FullName"));
                TeacherMobile.setText(rs.getString("TeacherMobile"));
                Email.setText(rs.getString("Email"));
                Address.setText(rs.getString("Address"));
                Age.setText(rs.getString("Age"));
                Gender.setText(rs.getString("Gender"));
                courseLabel.setText(rs.getString("CourseCode"));
            } else {
                JOptionPane.showMessageDialog(null, "No teacher found with this ID!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
    }
    //==============================================================================================================================================================
    //add student

    public static void AddStu(String FullName, int ID, String Email, String Password, String StuMobile, String ParentMobile, String Level, String Address, int Age, String Gender) {

        String sql = "INSERT INTO Students(FullName, ID, Email, Password, StuMobile, ParentMobile, Level, Address, Age, Gender)VALUES (?,?,?,?,?,?,?,?,?,?) ";

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            
            
            pst.setString(1, FullName);
            pst.setInt(2, ID);
            pst.setString(3, Email);
            pst.setString(4, Password);
            pst.setString(5, StuMobile);
            pst.setString(6, ParentMobile);
            pst.setString(7, Level);
            pst.setString(8, Address);
            pst.setInt(9, Age);
            pst.setString(10, Gender);
            int rs = pst.executeUpdate();

            if (rs > 0) {
                JOptionPane.showMessageDialog(null, "Added Successful!");
            } else {

                JOptionPane.showMessageDialog(null, "Error 404!");
            }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());

        }

    }
    //==============================================================================================================================================================
    //student search

    public static void GetStudentById(int studentId,JLabel idLabel, JLabel fullNameLabel, JLabel stuMobileLabel,JLabel parentMobileLabel, JLabel emailLabel, JLabel levelLabel,JLabel addressLabel, JLabel ageLabel, JLabel genderLabel) {

        String sql = "SELECT * FROM Students WHERE ID = ?";

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                idLabel.setText(String.valueOf(rs.getInt("ID")));
                fullNameLabel.setText(rs.getString("FullName"));
                stuMobileLabel.setText(rs.getString("StuMobile"));
                parentMobileLabel.setText(rs.getString("ParentMobile"));
                emailLabel.setText(rs.getString("Email"));
                levelLabel.setText(rs.getString("Level"));
                addressLabel.setText(rs.getString("Address"));
                ageLabel.setText(String.valueOf(rs.getInt("Age")));
                genderLabel.setText(rs.getString("Gender"));
            } else {
                JOptionPane.showMessageDialog(null, "Student not found!");
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());

        }

    }
    //==============================================================================================================================================================
    //add course

    public static void addCourse(int studentId, String courseId, String courseName) {
        String studentSql = "SELECT * FROM Students WHERE ID = ?";
        String addCourseSql = "INSERT INTO StudentCourses (student_id, course_id,course_name) VALUES (?, ?,?)";

        try (Connection con = DBC()) {
            try (PreparedStatement pst = con.prepareStatement(studentSql)) {
                pst.setInt(1, studentId);
                ResultSet rs = pst.executeQuery();

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(null, "Student does't exsist");
                    return;
                }
            }

            try (PreparedStatement pst = con.prepareStatement(addCourseSql)) {
                pst.setInt(1, studentId);
                pst.setString(2, courseId);
                pst.setString(3, courseName);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Course added for student successfully!");
            } catch (SQLException e) {               
                    JOptionPane.showMessageDialog(null, "This student is already registered for this course.");        
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }

    }
    //==============================================================================================================================================================
    //midterm grade mangment

    public static boolean MidtermGrade(int studentId, String courseId, double midtermGrade) {
        String sql = "UPDATE StudentCourses SET midterm_grade = ? WHERE student_id = ? AND course_id = ?";

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDouble(1, midtermGrade);
            pst.setInt(2, studentId);
            pst.setString(3, courseId);

            int rs = pst.executeUpdate();
            if (rs == 0) {
                JOptionPane.showMessageDialog(null, "No matching course found for this student.");
            } else {
            return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
        return false;
    }
//==============================================================================================================================================================
    //final grade mangment

    public static boolean FinalGrade(int studentId, String courseId, double finalGrade) {
        String sql = "UPDATE StudentCourses SET final_grade = ? WHERE student_id = ? AND course_id = ?";

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDouble(1, finalGrade);
            pst.setInt(2, studentId);
            pst.setString(3, courseId);

            int rs = pst.executeUpdate();
            if (rs == 0) {
                JOptionPane.showMessageDialog(null, "No matching course found for this student.");

            } else {

                return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
        return false;
    }
//==============================================================================================================================================================
    //student grade table

    public static DefaultTableModel StuGrade(int studentId) {
        String sql = "SELECT course_name,course_id, midterm_grade, final_grade FROM StudentCourses WHERE student_id = ?";
        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("Course ID");
        model.addColumn("Course Name");
        model.addColumn("Midterm Grade");
        model.addColumn("Final Grade");

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String courseId = rs.getString("course_id");
                String courseName = rs.getString("course_name");
                String midtermGrade = rs.getString("midterm_grade");
                String finalGrade = rs.getString("final_grade");

                model.addRow(new Object[]{courseId, courseName, midtermGrade, finalGrade});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }

        return model;
    }
//==============================================================================================================================================================
    //student courses table

    public static DefaultTableModel getStudentCourses(int studentId) {
        String sql = "SELECT course_name FROM StudentCourses WHERE student_id = ?";
        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("Time Table");

        try (Connection con = DBC(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String courseName = rs.getString("course_name");
                model.addRow(new Object[]{courseName});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }

        return model;
    }
    //==============================================================================================================================================================
    //delete student
    public static boolean DeleteStudent(int ID) {       
        String deleteCoursesSQL = "DELETE FROM StudentCourses WHERE student_id = ?";
        String deleteStudentSQL = "DELETE FROM Students WHERE ID = ?";

        try (Connection con = DBC()) {
        
            String checkSQL = "SELECT * FROM Students WHERE ID = ?";
            PreparedStatement pst1 = con.prepareStatement(checkSQL);
            pst1.setInt(1, ID);
            ResultSet rs = pst1.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "No student found with this ID.");
                return false;
            }

           
            PreparedStatement pst2 = con.prepareStatement(deleteCoursesSQL);
            pst2.setInt(1, ID);
            pst2.executeUpdate();

            
            PreparedStatement pst3 = con.prepareStatement(deleteStudentSQL);
            pst3.setInt(1, ID);
            int result = pst3.executeUpdate();

            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            return false;
        }
    }

    //==============================================================================================================================================================
    //delete teacher
    public static boolean DeleteTeacher(int ID) {
        String deleteTeacherSQL = "DELETE FROM Teachers WHERE ID = ?";

        try (Connection con = DBC()) {
            String checkSQL = "SELECT * FROM Teachers WHERE ID = ?";
            PreparedStatement pst1 = con.prepareStatement(checkSQL);
            pst1.setInt(1, ID);
            ResultSet rs = pst1.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "No teacher found with this ID.");
                return false;
            }

            PreparedStatement pst2 = con.prepareStatement(deleteTeacherSQL);
            pst2.setInt(1, ID);
            int result = pst2.executeUpdate();

            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            return false;
        }
    }


}
