package projectoop;
//==============================================================================================================================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//==============================================================================================================================================================

public class LoginPage extends JFrame implements ActionListener {

     JButton loginBtn, fogetPassBtn;
     JCheckBox adminCheck, StuCheck;
     JTextField usernameText, passwordText;
     JLabel userLabel, passLabel;
     ButtonGroup BtnGroup;

    static int id;
//==============================================================================================================================================================

    public LoginPage() {

        setTitle("OOP ANU Project");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
//==============================================================================================================================================================
        ImageIcon backgroundIcon = new ImageIcon("login.jpg");
        final Image backgroundImage = backgroundIcon.getImage();

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Log in Page");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font(null, Font.BOLD, 25));
        welcomeLabel.setBounds(320, 80, 150, 50);
        panel.add(welcomeLabel);

        JLabel SchoolManagmentLab = new JLabel("-School Management application-");
        SchoolManagmentLab.setForeground(Color.WHITE);
        SchoolManagmentLab.setFont(new Font(null, Font.BOLD, 25));
        SchoolManagmentLab.setBounds(220, 30, 500, 50);
        panel.add(SchoolManagmentLab);

        JLabel poweredLab = new JLabel("- Powered by the Admin -");
        poweredLab.setForeground(Color.WHITE);
        poweredLab.setBounds(320, 450, 170, 25);
        panel.add(poweredLab);
//==============================================================================================================================================================
        userLabel = new JLabel("Username :");
        userLabel.setForeground(Color.WHITE);
        userLabel.setBounds(250, 180, 100, 25);
        panel.add(userLabel);

        usernameText = new JTextField();
        usernameText.setBounds(350, 180, 180, 25);
        panel.add(usernameText);

        passLabel = new JLabel("Password :");
        passLabel.setForeground(Color.WHITE);
        passLabel.setBounds(250, 220, 100, 25);
        panel.add(passLabel);

        passwordText = new JPasswordField();
        passwordText.setBounds(350, 220, 180, 25);
        panel.add(passwordText);

        BtnGroup = new ButtonGroup();

        adminCheck = new JCheckBox("Admin");
        StuCheck = new JCheckBox("Student");
        adminCheck.setBounds(290, 333, 120, 35);
        StuCheck.setBounds(420, 333, 140, 35);
        adminCheck.setForeground(Color.WHITE);
        StuCheck.setForeground(Color.WHITE);
        adminCheck.setOpaque(false);
        StuCheck.setOpaque(false);
        BtnGroup.add(adminCheck);
        BtnGroup.add(StuCheck);

        panel.add(adminCheck);
        panel.add(StuCheck);

        loginBtn = new JButton("Login");
        loginBtn.setBounds(250, 280, 120, 35);
        loginBtn.setBackground(Color.RED);
        loginBtn.setForeground(Color.BLACK);
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(null);
        panel.add(loginBtn);

        fogetPassBtn = new JButton("Forget password?");
        fogetPassBtn.setBounds(400, 280, 140, 35);
        fogetPassBtn.setBackground(Color.WHITE);
        fogetPassBtn.setForeground(Color.BLACK);
        fogetPassBtn.setFocusPainted(false);
        fogetPassBtn.setBorder(null);
        panel.add(fogetPassBtn);

        add(panel);
        setVisible(true);

//==============================================================================================================================================================
        loginBtn.addActionListener(this);
        adminCheck.addActionListener(this);
        fogetPassBtn.addActionListener(this);
        StuCheck.addActionListener(this);
        usernameText.addActionListener(this);
    }
//==============================================================================================================================================================

    public static void main(String[] args) {
        new LoginPage();
    }
//==============================================================================================================================================================    

    @Override
    public void actionPerformed(ActionEvent e) {
        //classes objects
        User Stu = new Student();
        User admin = new Admin();
        Stu.setUsername(usernameText.getText());
        Stu.setPassword(passwordText.getText());
        admin.setUsername(usernameText.getText());
        admin.setPassword(passwordText.getText());
//==============================================================================================================================================================
        //admin login
        if (e.getSource() == loginBtn && adminCheck.isSelected()) {

            if (Database.AdminLogin(admin.getUsername(), admin.getPassword()) == true) {
                Database.StuCount(AdminPage.StuNum);
                Database.TeacherCount(AdminPage.TeacherNum);
                this.dispose();
            }

        } //==============================================================================================================================================================
        //student login
        else if (e.getSource() == loginBtn && StuCheck.isSelected()) {
            if (Database.StdLogin(Stu.getUsername(), Stu.getPassword()) == true) {
                this.dispose();
                id = Integer.parseInt(Stu.getUsername());
                Database.GetStudentById(id, StPage.stuInfo1, StPage.stuInfo2, StPage.stuInfo3, StPage.stuInfo4, StPage.stuInfo5, StPage.stuInfo6, StPage.stuInfo7, StPage.stuInfo8, StPage.stuInfo9);
            }

        } //==============================================================================================================================================================        
        //forget pass action
        else if (e.getSource() == fogetPassBtn) {
            JOptionPane.showMessageDialog(null, "please, contact your adminstrator");
        } //==============================================================================================================================================================
        //empty information action
        else if (e.getSource() == loginBtn) {
            if (Stu.getUsername().isEmpty() || admin.getUsername().isEmpty() && Stu.getPassword().isEmpty() || admin.getPassword().isEmpty()) {
                JOptionPane.showMessageDialog(null, "please,insert both username and password ");
            } else {
                JOptionPane.showMessageDialog(null, "please, select your role");
            }
        }
//==============================================================================================================================================================        
    }
}
