package projectoop;

public class Student extends User {
//==============================================================================================================================================================

    private String Emial;
    private String StuMobile;
    private String ParentMobile;
    private String Level;
    private String Address;
    private int Age;
    private String Gender;
//==============================================================================================================================================================

    public Student() {
    }

    public Student(int id, String userName, String password) {
        super(id, userName, password);
    }
//==============================================================================================================================================================

    public String getEmial() {
        return Emial;
    }

    public void setEmial(String Emial) {
        this.Emial = Emial;
    }

    public String getParentMobile() {
        return ParentMobile;
    }

    public void setParentMobile(String ParentMobile) {
        this.ParentMobile = ParentMobile;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String Level) {
        this.Level = Level;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getStuMobile() {
        return StuMobile;
    }

    public void setStuMobile(String StuMobile) {
        this.StuMobile = StuMobile;
    }

//==============================================================================================================================================================
    @Override
    public void displayFrame() {
        new StPage();
    }
//==============================================================================================================================================================

}
